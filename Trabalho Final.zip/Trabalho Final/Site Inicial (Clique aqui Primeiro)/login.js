function minhaFuncao() {
    let input = document.querySelector('#inputs')
    let text = `Boas vindas, ${input.value}`
    alert(text)
}

function redirect() {
    let text2 = `Obrigado! Estamos redirecionando... \n Clique em "Ok" para prosseguir!`
    alert(text2)
}

function password() {
    let senha = document.querySelector('#password')
    let text3 = `A senha ${senha.value} foi configurada e salva com sucesso!`
    alert(text3)
}

const divSelect = document.querySelector('div')
divSelect.id = 'div'
divSelect.insertAdjacentHTML('beforeend', '<div class="titulo"></div>')

const backTitle = document.querySelector('.titulo')
backTitle.insertAdjacentHTML('beforeend', '<h1>Bem Vindo!</h1> <p>Vamos começar o seu login!</p>')